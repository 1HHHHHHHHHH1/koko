// ✅ notification_service.dart
// إشعارات داخل التطبيق عبر Supabase Realtime
// لا تحتاج Firebase — تعمل مباشرة
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart' hide Provider;

final notificationServiceProvider =
    Provider<NotificationService>((ref) => NotificationService());

// ── نموذج الإشعار ──────────────────────────────────────
class AppNotification {
  final String id;
  final String title;
  final String body;
  final String? conversationId;
  final DateTime createdAt;
  bool isRead;

  AppNotification({
    required this.id,
    required this.title,
    required this.body,
    this.conversationId,
    required this.createdAt,
    this.isRead = false,
  });
}

// ── Service ────────────────────────────────────────────
class NotificationService {
  StreamSubscription? _sub;
  final _controller = StreamController<AppNotification>.broadcast();

  Stream<AppNotification> get notificationStream => _controller.stream;
  final List<AppNotification> notifications = [];

  // ✅ ابدأ الاستماع لرسائل جديدة
  void startListening(String currentUserId) {
    _sub?.cancel();

    _sub = Supabase.instance.client
        .from('messages')
        .stream(primaryKey: ['id'])
        .order('created_at', ascending: false)
        .listen((rows) {
          if (rows.isEmpty) return;
          final latest = rows.first;

          // تجاهل رسائل المستخدم نفسه
          if (latest['sender_id'] == currentUserId) return;

          final msgId    = latest['id'] as String;
          final content  = latest['content'] as String? ?? '';
          final convId   = latest['conversation_id'] as String?;

          // تجنب الإشعارات المكررة
          if (notifications.any((n) => n.id == msgId)) return;

          final notif = AppNotification(
            id:             msgId,
            title:          '💬 رسالة جديدة',
            body:           content.length > 60
                ? '${content.substring(0, 60)}...'
                : content,
            conversationId: convId,
            createdAt:      DateTime.now(),
          );

          notifications.insert(0, notif);
          if (notifications.length > 50) notifications.removeLast();

          _controller.add(notif);
        });
  }

  void stopListening() {
    _sub?.cancel();
    _sub = null;
  }

  void markAllRead() {
    for (final n in notifications) { n.isRead = true; }
  }

  int get unreadCount => notifications.where((n) => !n.isRead).length;

  void dispose() {
    stopListening();
    _controller.close();
  }
}

// ══════════════════════════════════════════════════════════
// ✅ Widget: شريط الإشعار العائم يظهر في أعلى الشاشة
// ══════════════════════════════════════════════════════════
class NotificationOverlay extends ConsumerStatefulWidget {
  final Widget child;
  const NotificationOverlay({super.key, required this.child});

  @override
  ConsumerState<NotificationOverlay> createState() =>
      _NotificationOverlayState();
}

class _NotificationOverlayState extends ConsumerState<NotificationOverlay>
    with SingleTickerProviderStateMixin {
  AppNotification? _current;
  late AnimationController _ctrl;
  late Animation<Offset>   _slide;
  Timer? _hideTimer;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 350));
    _slide = Tween<Offset>(begin: const Offset(0, -1), end: Offset.zero)
        .animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));

    // الاستماع للإشعارات
    final svc = ref.read(notificationServiceProvider);
    svc.notificationStream.listen(_show);
  }

  void _show(AppNotification notif) {
    if (!mounted) return;
    _hideTimer?.cancel();
    setState(() => _current = notif);
    _ctrl.forward(from: 0);
    _hideTimer = Timer(const Duration(seconds: 4), _hide);
  }

  void _hide() {
    _ctrl.reverse();
    Future.delayed(const Duration(milliseconds: 350), () {
      if (mounted) setState(() => _current = null);
    });
  }

  @override
  void dispose() {
    _ctrl.dispose();
    _hideTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        widget.child,
        if (_current != null)
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            left: 12, right: 12,
            child: SlideTransition(
              position: _slide,
              child: _NotifBanner(
                notif:   _current!,
                onTap: () {
                  _hide();
                  if (_current?.conversationId != null) {
                    Navigator.of(context).pushNamed(
                      '/messages/${_current!.conversationId}',
                    );
                  }
                },
                onClose: _hide,
              ),
            ),
          ),
      ],
    );
  }
}

class _NotifBanner extends StatelessWidget {
  final AppNotification notif;
  final VoidCallback    onTap;
  final VoidCallback    onClose;
  const _NotifBanner({required this.notif, required this.onTap, required this.onClose});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Material(
      elevation: 8,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
                color: theme.colorScheme.primary.withOpacity(0.3)),
          ),
          child: Row(
            children: [
              CircleAvatar(
                radius: 22,
                backgroundColor: theme.colorScheme.primary.withOpacity(0.15),
                child: Icon(Icons.message, color: theme.colorScheme.primary),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(notif.title,
                        style: theme.textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.bold)),
                    const SizedBox(height: 2),
                    Text(notif.body,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.bodySmall?.copyWith(
                            color: Colors.grey[600])),
                  ],
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close, size: 18),
                onPressed: onClose,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════
// ✅ أيقونة الجرس في AppBar مع عداد الإشعارات غير المقروءة
// ══════════════════════════════════════════════════════════
class NotificationBell extends ConsumerWidget {
  final VoidCallback? onTap;
  const NotificationBell({super.key, this.onTap});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final svc   = ref.watch(notificationServiceProvider);
    final count = svc.unreadCount;

    return Stack(
      children: [
        IconButton(
          icon: const Icon(Icons.notifications_outlined),
          onPressed: () {
            svc.markAllRead();
            onTap?.call();
          },
        ),
        if (count > 0)
          Positioned(
            right: 6, top: 6,
            child: Container(
              padding: const EdgeInsets.all(4),
              decoration: const BoxDecoration(
                color: Colors.red,
                shape: BoxShape.circle,
              ),
              child: Text(
                count > 9 ? '9+' : '$count',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ),
      ],
    );
  }
}
