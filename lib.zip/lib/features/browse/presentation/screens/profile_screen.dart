// ✅ profile_screen.dart — واجهة بروفايل كاملة تجلب البيانات من Supabase
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/supabase/supabase_service.dart';
import '../../../../models/user.dart';
import '../../../../providers/auth_provider.dart';
import '../../../../providers/likes_provider.dart';
import '../../../../core/router/app_router.dart';

// Provider لجلب بيانات مستخدم بعينه
final userProfileProvider =
    FutureProvider.family<User?, String>((ref, userId) async {
  final service = ref.watch(supabaseServiceProvider);
  final client  = service.client;
  final data    = await client
      .from('profiles')
      .select()
      .eq('id', userId)
      .maybeSingle();
  if (data == null) return null;
  return User.fromJson(data);
});

class ProfileScreen extends ConsumerWidget {
  final String userId;
  const ProfileScreen({super.key, required this.userId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme       = Theme.of(context);
    final profileAsync = ref.watch(userProfileProvider(userId));
    final currentUser  = ref.watch(currentUserProvider);
    final isMe         = currentUser?.id == userId;
    final isLiked      = ref.watch(isLikedProvider(userId));

    return Scaffold(
      body: profileAsync.when(
        loading: () =>
            const Center(child: CircularProgressIndicator()),

        error: (e, _) => Center(
            child: Text('Error: $e',
                style: TextStyle(color: Colors.red.shade600))),

        data: (user) {
          if (user == null) {
            return const Center(child: Text('Profile not found'));
          }
          return CustomScrollView(
            slivers: [
              // ── AppBar مع صورة ──────────────────────────────
              SliverAppBar(
                expandedHeight: 220,
                pinned: true,
                flexibleSpace: FlexibleSpaceBar(
                  background: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          theme.colorScheme.primary,
                          theme.colorScheme.secondary,
                        ],
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 48),
                        CircleAvatar(
                          radius: 50,
                          backgroundColor: Colors.white.withOpacity(0.2),
                          backgroundImage: user.avatar != null
                              ? NetworkImage(user.avatar!) : null,
                          child: user.avatar == null
                              ? Text(
                                  user.name.isNotEmpty
                                      ? user.name[0].toUpperCase() : '?',
                                  style: const TextStyle(
                                      fontSize: 36, color: Colors.white,
                                      fontWeight: FontWeight.bold))
                              : null,
                        ),
                        const SizedBox(height: 12),
                        Text(user.name,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 22,
                                fontWeight: FontWeight.bold)),
                        Text(
                          user.userType == 'investor'
                              ? 'Investor' : 'Entrepreneur',
                          style: TextStyle(
                              color: Colors.white.withOpacity(0.85),
                              fontSize: 14),
                        ),
                      ],
                    ),
                  ),
                ),
                actions: [
                  if (!isMe)
                    IconButton(
                      icon: Icon(
                          isLiked ? Icons.favorite : Icons.favorite_border,
                          color: isLiked ? Colors.red : Colors.white),
                      onPressed: () {
                        ref.read(likesProvider.notifier)
                            .toggleLike(userId, user.userType);
                      },
                    ),
                  if (isMe)
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.white),
                      onPressed: () {/* TODO: edit profile */},
                    ),
                ],
              ),

              // ── Body ────────────────────────────────────────
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ---- Stats chips ----
                      Row(
                        children: [
                          _StatCard(
                              icon: Icons.star,
                              value: user.averageRating
                                      ?.toStringAsFixed(1) ?? '—',
                              label: 'Rating',
                              color: Colors.amber),
                          const SizedBox(width: 12),
                          _StatCard(
                              icon: Icons.favorite,
                              value: '${user.totalLikes ?? 0}',
                              label: 'Likes',
                              color: Colors.red),
                          const SizedBox(width: 12),
                          _StatCard(
                              icon: Icons.rate_review,
                              value: '${user.totalRatings ?? 0}',
                              label: 'Reviews',
                              color: theme.colorScheme.primary),
                        ],
                      ),
                      const SizedBox(height: 24),

                      // ---- Bio ----
                      if (user.bio != null && user.bio!.isNotEmpty) ...[
                        _SectionTitle('About'),
                        const SizedBox(height: 8),
                        Text(user.bio!,
                            style: theme.textTheme.bodyMedium
                                ?.copyWith(height: 1.5)),
                        const SizedBox(height: 20),
                      ],

                      // ---- Company / Position ----
                      if (user.company != null || user.position != null) ...[
                        _SectionTitle('Work'),
                        const SizedBox(height: 8),
                        _InfoRow(Icons.business,
                            '${user.position ?? ''} at ${user.company ?? ''}'),
                        const SizedBox(height: 20),
                      ],

                      // ---- Location / Website ----
                      if (user.location != null || user.website != null) ...[
                        _SectionTitle('Details'),
                        const SizedBox(height: 8),
                        if (user.location != null)
                          _InfoRow(Icons.location_on, user.location!),
                        if (user.website != null)
                          _InfoRow(Icons.language, user.website!),
                        if (user.linkedIn != null)
                          _InfoRow(Icons.link, user.linkedIn!),
                        const SizedBox(height: 20),
                      ],

                      // ---- Industries ----
                      if (user.industries != null &&
                          user.industries!.isNotEmpty) ...[
                        _SectionTitle('Industries'),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8, runSpacing: 8,
                          children: user.industries!
                              .map((i) => Chip(label: Text(i)))
                              .toList(),
                        ),
                        const SizedBox(height: 20),
                      ],

                      // ---- CTA: Message ----
                      if (!isMe) ...[
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton.icon(
                            icon: const Icon(Icons.message_outlined),
                            label: const Text('Send Message'),
                            onPressed: () => context.go(Routes.conversations),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String   value;
  final String   label;
  final Color    color;

  const _StatCard({
    required this.icon,
    required this.value,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(height: 4),
            Text(value, style: TextStyle(
                fontWeight: FontWeight.bold, fontSize: 16, color: color)),
            Text(label, style: TextStyle(
                fontSize: 12, color: Colors.grey[600])),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) => Text(text,
      style: Theme.of(context).textTheme.titleMedium
          ?.copyWith(fontWeight: FontWeight.bold));
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String   text;
  const _InfoRow(this.icon, this.text);

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Row(
          children: [
            Icon(icon, size: 16, color: Colors.grey[500]),
            const SizedBox(width: 8),
            Expanded(
              child: Text(text,
                  style: Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.copyWith(color: Colors.grey[700])),
            ),
          ],
        ),
      );
}
